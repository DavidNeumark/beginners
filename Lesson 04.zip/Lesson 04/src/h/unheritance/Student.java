package h.unheritance;

public class Student extends Person {

	@Override
	public final void move() {
		super.move();
	}

}
