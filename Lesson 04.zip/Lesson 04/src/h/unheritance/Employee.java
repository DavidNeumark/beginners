package h.unheritance;

public class Employee extends Person {

}
