package h.unheritance;

public class Person {

	public void talk() {
		System.out.println("talk like a person");
	}

	public void move() {
		System.out.println("talk like a move");
	}

}
