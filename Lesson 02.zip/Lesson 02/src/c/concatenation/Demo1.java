package c.concatenation;

public class Demo1 {

	public static void main(String[] args) {
		
		String name = "David";
		int age = 25;
		String msg = name + " is " + age + " years old.";
		System.out.println(msg);
	}
}
