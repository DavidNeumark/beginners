package c.concatenation;

public class Demo2 {
	
	public static void main(String[] args) {
		
		String part1 = "There are";
		String part2 = "people for dinner.";
		int visitors = 5;
		
		System.out.println(part1 + " " + (visitors + 2) + " " + part2);
		
	}

}
