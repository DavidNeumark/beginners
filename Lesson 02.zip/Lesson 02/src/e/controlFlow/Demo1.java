package e.controlFlow;

public class Demo1 {

	public static void main(String[] args) {

		int r = (int) (Math.random() * 11);
		System.out.println(r);

		if (r > 5) {
			System.out.println("Big");
		}
	}
}
