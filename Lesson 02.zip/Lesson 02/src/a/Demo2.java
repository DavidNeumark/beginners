package a;

public class Demo2 {

	static int num; // class variable

	public static void main(String[] args) {
		System.out.println(num);
		int a; // declaration of a local variable
		a = 5;
		System.out.println(a);

		// other possible ways the create local data
		int x, y, z;
		x = 8;
		y = 6;
		z = 2;

		int n1 = 7, n2 = 6, n3 = 9;

		boolean bool = y == n2;
		System.out.println(bool);
	}

}
