package b;

public class Demo3 {

	public static void main(String[] args) {
		int a = 5, b = 3, sum;
		sum = a + b;
		
		double p = Math.pow(a, b);
		System.out.println(p);
		
	}
}
