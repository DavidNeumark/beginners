package b;

public class Demo1 {

	public static void main(String[] args) {
		int num = 10; //declaration and initialization
		System.out.println(num);
		num = 50; // assignment
		System.out.println(num);
		num = num + 5; // assignment (increment)
		System.out.println(num);
		
		num += 5; // assignment (increment)
		System.out.println(num);
		
		num = num + 1;
		num++;
	}
}
