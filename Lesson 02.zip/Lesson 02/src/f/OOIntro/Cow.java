package f.OOIntro;

public class Cow extends Animal {

	public void speak() {
		System.out.println("Moooo");
	}
}
