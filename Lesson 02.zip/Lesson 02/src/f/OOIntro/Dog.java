package f.OOIntro;

public class Dog extends Animal {

	public void speak() {
		System.out.println("Wooof");
	}
}
