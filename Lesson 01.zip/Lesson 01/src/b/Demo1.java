package b;

/*
 * multi line comment
 * line 1
 * line 2
 * line 3
 * */

/**
 * The class Demo1 is a demo for the 3 type comments.
 */
public class Demo1 {

	/**
	 * The main method runs the demo for the 3 type comments.
	 */
	public static void main(String[] args) {
		{
			// this is a comment
			int x = 5; // this is a comment
			int y = 6;
			System.out.println(x);
			System.out.println(y);
		}

	}
}
