package facades;

import ccc.objects.Company;

public class AdminFacade {

	/***
	 * Empty CTR
	 */
	public AdminFacade() {
	}

	/***
	 * Create company
	 * 
	 * @param c
	 */
	public void createCompany(Company c) {

	}

	/***
	 * Remove company
	 * 
	 * @param c
	 */
	public void removeCompany(Company c) {

	}

	/***
	 * Update company
	 * 
	 * @param c
	 */
	public void updateCompany(Company c) {

	}

}
