package sqlMethods;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLCreateTables {
	// SQL string;
	String sql = null;

	/***
	 * Creating Company table
	 * 
	 */
	public void createCompanyTable() {
		// URL data base path
		String url = "jdbc:derby://localhost:1527/MyDataBase";

		// Connecting
		try (Connection con = DriverManager.getConnection(url); Statement statement = con.createStatement()) {

			// Print when connected
			System.out.println("connected");

			// SQL creating table.
			sql = "CREATE TABLE Company(Id BIGINT PRIMARY KEY, CompName VARCHAR(30),Password VARCHAR(20),Email VARCHAR(20) )";
			statement.executeUpdate(sql);
			System.out.println(sql);

		} catch (SQLException e) {
			System.out.println("Could not connect to the data base");
		}

		// Disconnecting
		System.out.println("disconnected");
	}

	/***
	 * Creating Customers table
	 * 
	 */
	public void createCustomerTable() {
		// URL data base path
		String url = "jdbc:derby://localhost:1527/MyDataBase";

		// Connecting
		try (Connection con = DriverManager.getConnection(url); Statement statement = con.createStatement()) {

			// Print when connected
			System.out.println("connected");

			// SQL creating table.
			sql = "CREATE TABLE Customer(Id BIGINT PRIMARY KEY, CustName VARCHAR(30),Password VARCHAR(20))";
			statement.executeUpdate(sql);
			System.out.println(sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Could not connect to the data base");
		}

		// Disconnecting
		System.out.println("disconnected");
	}

	/***
	 * Creating Coupon table
	 * 
	 */
	public void createCouponTable() {
		// URL data base path
		String url = "jdbc:derby://localhost:1527/MyDataBase";

		// Connecting
		try (Connection con = DriverManager.getConnection(url); Statement statement = con.createStatement()) {

			// Print when connected
			System.out.println("connected");

			// SQL creating table.
			sql = "CREATE TABLE Coupon(Id BIGINT PRIMARY KEY, Title VARCHAR(20),StartDate DATE,EndDate DATE,Amount INT,Type VARCHAR(20),Message VARCHAR(20),Price DOUBLE,Image VARCHAR(30))";
			statement.executeUpdate(sql);
			System.out.println(sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Could not connect to the data base");
		}

		// Disconnecting
		System.out.println("disconnected");
	}

	/***
	 * Creating Costumer Coupon Join table
	 * 
	 */
	public void createCustomerCouponTable() {
		// URL data base path
		String url = "jdbc:derby://localhost:1527/MyDataBase";

		// Connecting
		try (Connection con = DriverManager.getConnection(url); Statement statement = con.createStatement()) {

			// Print when connected
			System.out.println("connected");

			// SQL creating table.
			sql = "CREATE TABLE CustomerCoupon(CustId BIGINT,CouponId BIGINT ,PRIMARY KEY(CustId,CouponId))";
			statement.executeUpdate(sql);
			System.out.println(sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Could not connect to the data base");
		}

		// Disconnecting
		System.out.println("disconnected");
	}

	/***
	 * Creating Company Coupon Join table
	 * 
	 */
	public void createCompanyCouponTable() {
		// URL data base path
		String url = "jdbc:derby://localhost:1527/MyDataBase";

		// Connecting
		try (Connection con = DriverManager.getConnection(url); Statement statement = con.createStatement()) {

			// Print when connected
			System.out.println("connected");

			// SQL creating table.
			sql = "CREATE TABLE CompanyCoupon(CompId BIGINT,CouponId BIGINT ,PRIMARY KEY(CompId,CouponId))";
			statement.executeUpdate(sql);
			System.out.println(sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Could not connect to the data base");
		}

		// Disconnecting
		System.out.println("disconnected");
	}
}
