package couponExceptions.couponExceptions;

public class NullCouponException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullCouponException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NullCouponException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NullCouponException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NullCouponException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NullCouponException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
