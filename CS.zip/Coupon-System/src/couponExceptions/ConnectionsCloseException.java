package couponExceptions;

import java.sql.SQLException;

public class ConnectionsCloseException extends SQLException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConnectionsCloseException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(String arg0, String arg1, int arg2, Throwable arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(String arg0, String arg1, int arg2) {
		super(arg0, arg1, arg2);
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(String arg0, String arg1, Throwable arg2) {
		super(arg0, arg1, arg2);
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(String arg0, String arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ConnectionsCloseException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
