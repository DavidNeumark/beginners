package couponExceptions.customerExceptions;

public class NullCustomerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullCustomerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NullCustomerException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NullCustomerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NullCustomerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NullCustomerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
