package DBDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import ccc.objects.Coupon;
import ccc.objects.Coupon.CouponType;
import connections.ConnectionPool;
import couponExceptions.couponExceptions.NullCouponException;
import interfaces.CouponDAO;

public class CouponDBDAO implements CouponDAO {
	// Class attributes
	private ConnectionPool pool;
	private static String sql;

	/***
	 * Empty CTR
	 */
	public CouponDBDAO() {
	}

	/***
	 * Creating coupon into the data base using the connection pool
	 */
	@Override
	public void createCoupon(Coupon c) {
		// The SQL command
		sql = "INSERT INTO Coupon VALUES(?,?,?,?,?,?,?,?,?)";
		// Getting connection
		Connection currentConnection = pool.getConnection();

		// Executing the SQL prepared statement
		try (PreparedStatement pstmt = currentConnection.prepareStatement(sql);) {
			// Connect to the URL

			pstmt.setLong(1, c.getId());
			pstmt.setString(2, c.getTitle());
			pstmt.setDate(3, c.getStartDate());
			pstmt.setDate(4, c.getEndDate());
			pstmt.setInt(5, c.getAmount());
			pstmt.setObject(6, c.getCouponType());
			pstmt.setString(7, c.getMessage());
			pstmt.setDouble(8, c.getPrice());
			pstmt.setString(9, c.getImage());

			// Updating the values
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}

	}

	/***
	 * Removing a coupon from the data base using the connection pool
	 */
	@Override
	public void removeCoupon(Coupon c) {
		// SQL statement
		sql = "DELETE FROM Coupon WHERE ID =" + c.getId();

		// Taking connection from the pool
		Connection currentConnection = pool.getConnection();

		try (Statement stmnt = currentConnection.createStatement()) {

			stmnt.executeUpdate(sql);
		} catch (SQLException e) {
			System.err.println("Couldnt connect the driver");
		} finally {
			// Giving back the connection to the pool
			pool.returnConnection(currentConnection);
		}

	}

	/***
	 * Updating coupon on the data base by using the connection pool base on the
	 * coupon id
	 */
	@Override
	public void updateCoupon(Coupon c) {
		// The SQL command
		sql = "UPDATE Coupon SET(?,?,?,?,?,?,?,?,?) WHERE ID=" + c.getId();

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Giving the current connection the SQL statement
		try (PreparedStatement pstmt = currentConnection.prepareStatement(sql);) {

			pstmt.setLong(1, c.getId());
			pstmt.setString(2, c.getTitle());
			pstmt.setDate(3, c.getStartDate());
			pstmt.setDate(4, c.getEndDate());
			pstmt.setInt(5, c.getAmount());
			pstmt.setObject(6, c.getCouponType());
			pstmt.setString(7, c.getMessage());
			pstmt.setDouble(8, c.getPrice());
			pstmt.setString(9, c.getImage());

			// Updating the values
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
	}

	/***
	 * Get coupon from the data base on the id using the connection pool
	 */
	@Override
	public Coupon getCoupon(long id) throws NullCouponException {
		Coupon coupon = null;

		// SQL statement
		sql = "SELECT * FROM COUPON WHERE ID=" + id;

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Making a statement
		try (Statement stmnt = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = stmnt.executeQuery(sql);

			// Taking the data
			long id1 = rs.getLong(1);
			String title = rs.getString(2);
			Date startDate = rs.getDate(3);
			Date endDate = rs.getDate(4);
			int amount = rs.getInt(5);
			CouponType type = (CouponType) rs.getObject(6);
			String message = rs.getString(7);
			double price = rs.getDouble(8);
			String image = rs.getString(9);

			coupon = new Coupon(id1, title, startDate, endDate, amount, type, message, price, image);

		} catch (SQLException e) {
			System.err.println("Couldnt connect the driver");
		} finally {
			pool.returnConnection(currentConnection);
		}
		// Checking if coupon was read successful
		if (coupon == null) {
			throw new NullCouponException("Coupon was not read successful");
		} else {
			return coupon;
		}
	}

	@Override
	public Set<Coupon> getAllCoupon() throws NullCouponException {
		Set<Coupon> coupons = new HashSet<>();
		Coupon coupon = null;

		// SQL statement
		sql = "SELECT * FROM COUPON";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Making a statement
		try (Statement stmnt = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = stmnt.executeQuery(sql);

			// Taking the data
			while (rs.next()) {
				long id1 = rs.getLong(1);
				String title = rs.getString(2);
				Date startDate = rs.getDate(3);
				Date endDate = rs.getDate(4);
				int amount = rs.getInt(5);
				CouponType type = (CouponType) rs.getObject(6);
				String message = rs.getString(7);
				double price = rs.getDouble(8);
				String image = rs.getString(9);

				coupon = new Coupon(id1, title, startDate, endDate, amount, type, message, price, image);
				coupons.add(coupon);
			}
		} catch (SQLException e) {
			System.err.println("Couldnt connect the driver");
		} finally {
			pool.returnConnection(currentConnection);
		}
		// Checking if coupon was read successful
		if (coupons.isEmpty()) {
			throw new NullCouponException("Coupon was not read successful");
		} else {
			return coupons;
		}
	}

	@Override
	public Set<Coupon> getCouponByType(CouponType type) throws NullCouponException {
		Set<Coupon> coupons = new HashSet<>();
		Coupon coupon = null;

		// SQL statement
		sql = "SELECT * FROM COUPON WHERE Type=" + type;

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Making a statement
		try (Statement stmnt = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = stmnt.executeQuery(sql);

			// Taking the data
			while (rs.next()) {
				long id1 = rs.getLong(1);
				String title = rs.getString(2);
				Date startDate = rs.getDate(3);
				Date endDate = rs.getDate(4);
				int amount = rs.getInt(5);
				CouponType type1 = (CouponType) rs.getObject(6);
				String message = rs.getString(7);
				double price = rs.getDouble(8);
				String image = rs.getString(9);

				coupon = new Coupon(id1, title, startDate, endDate, amount, type1, message, price, image);
				coupons.add(coupon);
			}
		} catch (SQLException e) {
			System.err.println("Couldnt connect the driver");
		} finally {
			pool.returnConnection(currentConnection);
		}
		// Checking if coupon was read successful
		if (coupon == null) {
			throw new NullCouponException("Coupon was not read successful");
		} else {
			return coupons;
		}
	}

}
