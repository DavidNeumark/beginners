package DBDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import ccc.objects.Coupon;
import ccc.objects.Coupon.CouponType;
import ccc.objects.Customer;
import connections.ConnectionPool;
import couponExceptions.couponExceptions.NullCouponException;
import couponExceptions.customerExceptions.NullCustomerException;
import interfaces.CustomerDAO;

public class CustomerDBDAO implements CustomerDAO {
	// Class attributes
	private ConnectionPool pool;
	private static String sql;

	/***
	 * Empty CTR
	 */
	public CustomerDBDAO() {
	}

	/***
	 * Creating customer into the data base using the connection pool
	 */
	@Override
	public void createCustomer(Customer c) {
		// The SQL statement
		sql = "INSERT INTO Customer(?,?,?)";

		// Using the pool for connecting the data base
		Connection currentConnection = pool.getConnection();

		// Execute the SQL command
		try (PreparedStatement pstmt = currentConnection.prepareStatement(sql);) {

			pstmt.setLong(1, c.getId());
			pstmt.setString(2, c.getCustName());
			pstmt.setString(3, c.getPassword());

			// Updating the values
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
	}

	/**
	 * Removing customer from the data base using the connection pool
	 */
	@Override
	public void removeCustomers(Customer c) {
		// The SQL command
		sql = "DELETE FROM Customer WHERE ID =" + c.getId();

		// Using the connection pool
		Connection currentConnection = pool.getConnection();

		// Execute the SQL command
		try (Statement stmnt = currentConnection.createStatement()) {

			stmnt.executeUpdate(sql);
		} catch (SQLException e) {
			System.err.println("Couldnt connect the data base");
		} finally {
			pool.returnConnection(currentConnection);
		}

	}

	/***
	 * Updating Customer to the data base using the connection pool
	 */
	@Override
	public void updateCustomer(Customer c) {
		// The SQL command
		sql = "UPDATE Customer SET(?,?,?) WHERE ID=" + c.getId();

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Giving the current connection the SQL statement
		try (PreparedStatement pstmt = currentConnection.prepareStatement(sql);) {

			pstmt.setLong(1, c.getId());
			pstmt.setString(2, c.getCustName());
			pstmt.setString(3, c.getPassword());

			// Updating the values
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
	}

	/***
	 * Returning customer base on id parameter using the connection pool
	 */
	@Override
	public Customer getCustomer(long id) throws NullCustomerException {
		Customer c = null;
		// The SQL command
		sql = "SELECT * FROM Customer WHERE ID =" + id;

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Taking the data
			long id1 = rs.getLong(1);
			String custName = rs.getString(2);
			String password = rs.getString(3);

			// Making a company object
			c = new Customer(id1, custName, password);

		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
		// Checking if the company was read successful
		if (c == null) {
			throw new NullCustomerException("Customer was not read succesful");
		} else {
			return c;
		}
	}

	/***
	 * Return set of all customer using the connection pool
	 */
	@Override
	public Set<Customer> getAllCustomer() throws NullCustomerException {
		Customer customer;
		Set<Customer> customers = new HashSet<>();
		// The SQL command
		sql = "SELECT * FROM Customer";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Running over the company table
			while (rs.next()) {
				// Taking the data
				long id = rs.getLong(1);
				String custName = rs.getString(2);
				String password = rs.getString(3);

				// Making a company object
				customer = new Customer(id, custName, password);
				// Adding to the set
				customers.add(customer);

			}

		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
		// Checking if companies was read successful
		if (customers.isEmpty()) {
			throw new NullCustomerException("Companies was not read succesful");
		} else {
			return customers;
		}
	}

	/**
	 * Return set of coupons of the customers using the connection pool
	 */
	@Override
	public Set<Coupon> getAllCoupons() throws NullCouponException {

		// Single coupon
		Coupon coupon;

		// Making a set
		Set<Coupon> coupons = new HashSet<>();

		// The SQL command
		sql = "SELECT * FROM Coupon INNER JOIN CustomerCoupon ON Coupon.id = CustomerCoupon.CouponId ";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Running over the company table
			while (rs.next()) {
				// Taking the data
				long id = rs.getLong(1);
				String title = rs.getString(2);
				Date startDate = rs.getDate(3);
				Date endDate = rs.getDate(4);
				int amount = rs.getInt(5);
				CouponType type = (CouponType) rs.getObject(6);
				String message = rs.getString(7);
				double price = rs.getDouble(8);
				String image = rs.getString(9);

				// Making a company object
				coupon = new Coupon(id, title, startDate, endDate, amount, type, message, price, image);
				// Adding to the set
				coupons.add(coupon);

			}

		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
		// Checking if coupons was read successful
		if (coupons.isEmpty()) {
			throw new NullCouponException("Companies was not read succesful");
		} else {
			return coupons;
		}
	}

	/***
	 * Return true when custName + password fit to another exist custName +
	 * password on the data base
	 */
	@Override
	public boolean login(String custName, String password) {
		// Company name and password
		String currentAnswer = custName + password;
		boolean checker = false;
		// The SQL command
		sql = "SELECT * FROM Customer";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Running over the company table
			while (rs.next()) {
				String name = rs.getString(2);
				String custPassword = rs.getString(3);
				String fitAnswer = name + custPassword;
				// Checking if it fits and if it does - break
				if (fitAnswer.equals(currentAnswer)) {
					checker = true;
					break;
				} else {
					checker = false;
				}
			}
			// Case could'nt connect the URL
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		}
		// Return true if the name and the password fits
		if (checker == true) {
			return true;
		} else {
			return false;
		}
	}

}
