package DBDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import ccc.objects.Company;
import ccc.objects.Coupon;
import ccc.objects.Coupon.CouponType;
import connections.ConnectionPool;
import couponExceptions.companyExceptions.NullCompanyException;
import couponExceptions.couponExceptions.NullCouponException;
import interfaces.CompanyDAO;

public class CompanyDBDAO implements CompanyDAO {
	// Class attributes
	private String sql;

	private ConnectionPool pool;

	/***
	 * Empty CTR
	 */
	public CompanyDBDAO() {
	}

	/***
	 * Creating a company on the data base by using the connection pool
	 */
	@Override
	public void createCompany(Company c) {
		// The SQL command
		sql = "INSERT INTO Company VALUES(?,?,?,?)";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Giving the current connection SQL statement and execute
		try (PreparedStatement pstmt = currentConnection.prepareStatement(sql);) {

			pstmt.setLong(1, c.getId());
			pstmt.setString(2, c.getCompName());
			pstmt.setString(3, c.getPassword());
			pstmt.setString(4, c.getEmail());

			// Updating the values
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
	}

	/***
	 * Removing a company from the data base by using the connection pool
	 */
	@Override
	public void removeCompany(Company c) {
		// The SQL command
		sql = "DELETE FROM Company WHERE ID =" + c.getId();

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Giving the current connection the URL path
			statement.executeUpdate(sql);
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
	}

	/***
	 * Updating company on the data base by using the connection pool base on
	 * the company id
	 */
	@Override
	public void updateCompany(Company c) {
		// The SQL command
		sql = "UPDATE Company SET(?,?,?) WHERE ID=" + c.getId();

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Giving the current connection the SQL statement
		try (PreparedStatement pstmt = currentConnection.prepareStatement(sql);) {

			pstmt.setLong(1, c.getId());
			pstmt.setString(2, c.getCompName());
			pstmt.setString(3, c.getPassword());
			pstmt.setString(3, c.getEmail());

			// Updating the values
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
	}

	/***
	 * Get company base on company id
	 */
	@Override
	public Company getCompany(long id) throws NullCompanyException {
		Company c = null;
		// The SQL command
		sql = "SELECT * FROM Company WHERE ID =" + id;

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Taking the data
			long id1 = rs.getLong(1);
			String name = rs.getString(2);
			String password = rs.getString(3);
			String email = rs.getString(4);

			// Making a company object
			c = new Company(id1, name, password, email);

		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
		// Checking if the company was read successful
		if (c == null) {
			throw new NullCompanyException("Company was not read succesful");
		} else {
			return c;
		}
	}

	/***
	 * Get all companies on the data base
	 */
	@Override
	public Set<Company> getAllCompanies() throws NullCompanyException {
		Company company;
		Set<Company> companies = new HashSet<>();
		// The SQL command
		sql = "SELECT * FROM Company";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Running over the company table
			while (rs.next()) {
				// Taking the data
				long id = rs.getLong(1);
				String name = rs.getString(2);
				String password = rs.getString(3);
				String email = rs.getString(4);

				// Making a company object
				company = new Company(id, name, password, email);
				// Adding to the set
				companies.add(company);

			}

		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
		// Checking if companies was read successful
		if (companies.isEmpty()) {
			throw new NullCompanyException("Companies was not read succesful");
		} else {
			return companies;
		}
	}

	/***
	 * Get all coupons on the data base that have the same id as the couponId
	 * from companyCoupon table
	 */
	@Override
	public Set<Coupon> getAllCoupons() throws NullCouponException {

		// Single coupon
		Coupon coupon;

		// Making a set
		Set<Coupon> coupons = new HashSet<>();

		// The SQL command
		sql = "SELECT * FROM Coupon INNER JOIN CompanyCoupon ON Coupon.id = CompanyCoupon.CouponId ";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Running over the company table
			while (rs.next()) {
				// Taking the data
				long id = rs.getLong(1);
				String title = rs.getString(2);
				Date startDate = rs.getDate(3);
				Date endDate = rs.getDate(4);
				int amount = rs.getInt(5);
				CouponType type = (CouponType) rs.getObject(6);
				String message = rs.getString(7);
				double price = rs.getDouble(8);
				String image = rs.getString(9);

				// Making a company object
				coupon = new Coupon(id, title, startDate, endDate, amount, type, message, price, image);
				// Adding to the set
				coupons.add(coupon);

			}

		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		} finally {
			// Return the connection to the pool
			pool.returnConnection(currentConnection);
		}
		// Checking if coupons was read successful
		if (coupons.isEmpty()) {
			throw new NullCompanyException("Companies was not read succesful");
		} else {
			return coupons;
		}

	}

	/***
	 * Return true when compName + password fit to another exist compName +
	 * password on the data base
	 */
	@Override
	public boolean login(String compName, String password) {
		// Company name and password
		String currentAnswer = compName + password;
		boolean checker = false;
		// The SQL command
		sql = "SELECT * FROM Company";

		// Using the pool
		Connection currentConnection = pool.getConnection();

		// Make a statement
		try (Statement statement = currentConnection.createStatement()) {

			// Making a result set
			ResultSet rs = statement.executeQuery(sql);

			// Running over the company table
			while (rs.next()) {
				String name = rs.getString(2);
				String compPassword = rs.getString(3);
				String fitAnswer = name + compPassword;
				// Checking if it fits and if it does - break
				if (fitAnswer.equals(currentAnswer)) {
					checker = true;
					break;
				} else {
					checker = false;
				}
			}
			// Case could'nt connect the URL
		} catch (SQLException e) {
			System.err.println("Couldnt find the path of the url");
		}
		// Return true if the name and the password fits
		if (checker == true) {
			return true;
		} else {
			return false;
		}
	}

}
