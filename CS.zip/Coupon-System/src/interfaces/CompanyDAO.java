package interfaces;

import java.util.Set;

import ccc.objects.Company;
import ccc.objects.Coupon;

/***
 * Interface for company
 * 
 * @author enosh
 *
 */
public interface CompanyDAO {

	void createCompany(Company c);

	void removeCompany(Company c);

	void updateCompany(Company c);

	Company getCompany(long id);

	Set<Company> getAllCompanies();

	Set<Coupon> getAllCoupons();

	boolean login(String compName, String password);
}
