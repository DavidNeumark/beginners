package interfaces;

import java.util.Set;

import ccc.objects.Coupon;
import ccc.objects.Coupon.CouponType;

/***
 * Interface for coupon
 * 
 * @author enosh
 *
 */
public interface CouponDAO {

	void createCoupon(Coupon c);

	void removeCoupon(Coupon c);

	void updateCoupon(Coupon c);

	Coupon getCoupon(long id);

	Set<Coupon> getAllCoupon();

	Set<Coupon> getCouponByType(CouponType type);

}
