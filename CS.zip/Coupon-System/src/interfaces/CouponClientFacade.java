package interfaces;

public interface CouponClientFacade {
}
