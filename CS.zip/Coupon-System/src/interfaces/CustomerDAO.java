package interfaces;

import java.util.Set;

import ccc.objects.Coupon;
import ccc.objects.Customer;

/***
 * Interface for customers
 * 
 * @author enosh
 *
 */
public interface CustomerDAO {

	void createCustomer(Customer c);

	void removeCustomers(Customer c);

	void updateCustomer(Customer c);

	Customer getCustomer(long id);

	Set<Customer> getAllCustomer();

	Set<Coupon> getAllCoupons();

	boolean login(String custName, String password);
}
