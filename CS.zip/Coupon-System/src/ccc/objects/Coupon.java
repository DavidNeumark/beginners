package ccc.objects;

import java.sql.Date;

import couponExceptions.PrimaryKeyException;

public class Coupon {
	// Class attributes
	private long id;// PK
	private String title;
	private Date startDate;
	private Date endDate;
	private int amount;
	private CouponType type;
	private String message;
	private double price;
	private String image;

	/***
	 * Empty CTR
	 */
	public Coupon() {
	}

	/***
	 * CTR using all parameters
	 * 
	 * @param id
	 * @param title
	 * @param startDate
	 * @param endDate
	 * @param amount
	 * @param type
	 * @param message
	 * @param price
	 * @param image
	 */
	public Coupon(long id, String title, Date startDate, Date endDate, int amount, CouponType type, String message,
			double price, String image) {
		super();
		this.id = id;
		this.title = title;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.type = type;
		this.message = message;
		this.price = price;
		this.image = image;
	}

	/***
	 * Get id
	 * 
	 * @return
	 */
	public long getId() {
		return id;
	}

	/***
	 * Set id ! throws runtime exception
	 * 
	 * @param id
	 */
	public void setId(long id) throws PrimaryKeyException {
		this.id = id;
	}

	/***
	 * Get title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/***
	 * Set title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/***
	 * Get start date
	 * 
	 * @return
	 */
	public Date getStartDate() {
		return startDate;
	}

	/***
	 * Set start date
	 * 
	 * @param startDate
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/***
	 * Get end date
	 * 
	 * @return
	 */
	public Date getEndDate() {
		return endDate;
	}

	/***
	 * Set end date
	 * 
	 * @param endDate
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/***
	 * Get amount of coupons
	 * 
	 * @return
	 */
	public int getAmount() {
		return amount;
	}

	/***
	 * Set amount of coupons
	 * 
	 * @param amount
	 */
	public void setAmount(int amount) {
		this.amount = amount;
	}

	/***
	 * Get type of coupons(ENUMS)
	 * 
	 * @return
	 */
	public CouponType getCouponType() {
		return type;
	}

	/***
	 * Set type of coupons(ENUMS)
	 * 
	 * @param type
	 */
	public void setCouponType(CouponType type) {
		this.type = type;
	}

	/***
	 * Get message (coupon's details)
	 * 
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/***
	 * Set message (coupon's details)
	 * 
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/***
	 * Get coupon's price
	 * 
	 * @return
	 */
	public double getPrice() {
		return price;
	}

	/***
	 * Set coupon's price
	 * 
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/***
	 * Get image string path
	 * 
	 * @return
	 */
	public String getImage() {
		return image;
	}

	/***
	 * Set image string path
	 * 
	 * @param image
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/***
	 * Enum types
	 * 
	 * @author enosh
	 *
	 */
	public enum CouponType {
		RESTURANS, ELECTRICITY, FOOD, HEALTH, SPORTS, CAMPING, TRAVELLING;
	}
}
