package ccc.objects;

import java.util.List;

import couponExceptions.PrimaryKeyException;

public class Company {
	// Class attributes
	private long id; // PK
	private String compName;
	private String password;
	private String email;
	private List<Coupon> coupons;

	/***
	 * Empty CTR
	 */
	public Company() {
	}

	/**
	 * CTR using all fields
	 * 
	 * @param id
	 * @param compName
	 * @param password
	 * @param email
	 */
	public Company(long id, String compName, String password, String email) {
		super();
		this.id = id;
		this.compName = compName;
		this.password = password;
		this.email = email;
	}

	/**
	 * Get company id
	 * 
	 * @return
	 */
	public long getId() {
		return id;
	}

	/**
	 * Set company id ! throws runtime exception
	 * 
	 * @param iD
	 */
	public void setId(long id) throws PrimaryKeyException {
		this.id = id;
	}

	/***
	 * Get company name
	 * 
	 * @return
	 */
	public String getCompName() {
		return compName;
	}

	/***
	 * Set company name
	 * 
	 * @param cOMP_NAME
	 */
	public void setCompName(String compName) {
		this.compName = compName;
	}

	/***
	 * Get password
	 * 
	 * @return
	 */
	public String getPassword() {
		return password;
	}

	/***
	 * Set password
	 * 
	 * @param pASSWORD
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/***
	 * Get email
	 * 
	 * @return
	 */
	public String getEmail() {
		return email;
	}

	/***
	 * Set email
	 * 
	 * @param eMAIL
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/***
	 * Get coupons
	 * 
	 * @return
	 */
	public List<Coupon> getCoupons() {
		return coupons;
	}

	/***
	 * Set coupons
	 * 
	 * @param coupons
	 */
	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}

	/***
	 * Override ToString
	 */
	@Override
	public String toString() {
		return "Company [id=" + id + ", compName=" + compName + ", password=" + password + ", email=" + email
				+ ", coupons=" + coupons + "]";
	}

}
