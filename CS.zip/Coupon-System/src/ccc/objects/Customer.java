package ccc.objects;

import java.util.List;

import couponExceptions.PrimaryKeyException;

public class Customer {
	// Class attributes
	private long id;// PK
	private String custName;
	private String password;
	private List<Coupon> coupons;

	/***
	 * Empty CTR
	 */
	public Customer() {
	}

	/***
	 * CTR using all fields
	 * 
	 * @param id
	 * @param custName
	 * @param password
	 */
	public Customer(long id, String custName, String password) {
		this.id = id;
		this.custName = custName;
		this.password = password;
	}

	/***
	 * Get id
	 * 
	 * @return
	 */
	public long getId() {
		return id;
	}

	/***
	 * Set id !throws runtime exception
	 * 
	 * @param iD
	 */
	public void setId(long id) throws PrimaryKeyException {
		this.id = id;
	}

	/***
	 * Get customers name
	 * 
	 * @return
	 */
	public String getCustName() {
		return custName;
	}

	/***
	 * Set customers name
	 * 
	 * @param custName
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}

	/***
	 * Get password
	 * 
	 * @return
	 */
	public String getPassword() {
		return password;
	}

	/***
	 * Set password
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/***
	 * Get coupons
	 * 
	 * @return
	 */
	public List<Coupon> getCoupons() {
		return coupons;
	}

	/***
	 * Set coupons
	 * 
	 * @param coupons
	 */
	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}

	/***
	 * Override ToString
	 */
	@Override
	public String toString() {
		return "Customer [id=" + id + ", custName=" + custName + ", password=" + password + ", coupons=" + coupons
				+ "]";
	}

}
