package main;

import sqlMethods.SQLCreateTables;

public class SqlLuncher {

	public static void main(String[] args) {
		/***
		 * Loading driver
		 */
		// Driver path
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		// Loading the driver from class
		try {
			Class.forName(driverName);
			System.out.println("driver loaded: " + driverName);
		} catch (ClassNotFoundException e) {
			System.err.println("Driver was not connected, Class not found.");
		}

		// SQL Methods
		SQLCreateTables createTables = new SQLCreateTables();
		createTables.createCompanyTable();
		createTables.createCustomerTable();
		createTables.createCouponTable();
		createTables.createCustomerCouponTable();
		createTables.createCompanyCouponTable();
	}

}
