package client;

import couponExceptions.adminExceptions.PasswordNotCorrect;

public abstract class CouponClientFacade {

	/***
	 * Empty CTR
	 */
	public CouponClientFacade() {
	}

	/***
	 * Abstract method for logging in
	 * 
	 * @param name
	 * @param password
	 */
	public abstract void loggingIn(String name, String password, ClientType type) throws PasswordNotCorrect;

	/***
	 * ENUM for types of clients
	 * 
	 * @author enosh
	 *
	 */
	public enum ClientType {
		ADMIN, COMPANY, CUSTOMER;
	}
}
