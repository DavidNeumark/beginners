package client;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import DBDAO.CompanyDBDAO;
import ccc.objects.Company;
import connections.ConnectionPool;
import couponExceptions.adminExceptions.CompanyNameExist;
import couponExceptions.adminExceptions.PasswordNotCorrect;

public class AdminFacade extends CouponClientFacade {
	// Class attributes
	private boolean loggedIn = false;
	private ClientType type;
	// LoggIn attributes
	private static String sql;
	private static ConnectionPool pool;

	private static CompanyDBDAO companydb = new CompanyDBDAO();

	private static final String USERNAME = "admin";
	private static final String PASSWORD = "1234";

	/***
	 * CTR with fields that using for logging in
	 * 
	 * @throws PasswordNotCorrect
	 */
	public AdminFacade(String userName, String password) throws PasswordNotCorrect {
		this.type = ClientType.ADMIN;
		loggingIn(userName, password, type);
	}

	/***
	 * Adding company while the name not exist in the data base using the
	 * connection pool
	 * 
	 * @param id
	 * @param compName
	 * @param password
	 * @param email
	 * @throws CompanyNameExist
	 */
	public void addingCompany(long id, String compName, String password, String email) throws CompanyNameExist {

		// Checking if we logged in
		if (loggedIn == false) {
			return;
		}

		// Result checker
		boolean checker = false;

		// Company object
		Company c;

		// SQL statement
		sql = "SELECT * FROM Company";

		// Using the pool for connect
		Connection currentConnection = pool.getConnection();

		try (Statement stmt = currentConnection.createStatement()) {
			ResultSet rs = stmt.getResultSet();

			// Checking if name already exist
			while (rs.next()) {
				String name = rs.getString(2);
				if (name.equals(compName)) {
					checker = true;
				}
			}

			if (checker == false) {
				c = new Company(id, compName, password, email);
				companydb.createCompany(c);
			} else {
				throw new CompanyNameExist("Company name exist");
			}
		} catch (SQLException e) {
			System.err.println("Could not connect");
		} finally {
			pool.returnConnection(currentConnection);
		}
	}

	/***
	 * Implements the logging method as ADMIN;
	 * 
	 * @param name
	 * @param password
	 * @param type
	 * @throws PasswordNotCorrect
	 */
	@Override
	public void loggingIn(String name, String password, ClientType type) throws PasswordNotCorrect {
		// Checking logging in while creating the object
		if (USERNAME.equals(name) && PASSWORD.equals(password)) {
			loggedIn = true;
		} else {
			throw new PasswordNotCorrect("Password or UserName was not correct");
		}
	}

}
