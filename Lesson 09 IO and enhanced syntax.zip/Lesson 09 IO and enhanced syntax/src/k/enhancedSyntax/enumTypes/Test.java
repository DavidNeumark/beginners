package k.enhancedSyntax.enumTypes;

public class Test {

	public static void main(String[] args) {
		Car c1 = new Car(0, CarColor.BLUE);
		Car c2 = new Car(10, CarColor.RED);
	}
}
