package k.enhancedSyntax.enumTypes;

public enum CarColor {

	WHITE, BLACK, RED, GREEN, BLUE;
}
