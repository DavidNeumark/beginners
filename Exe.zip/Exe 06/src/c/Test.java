package c;

public class Test {

	public static void main(String[] args) {

		MyTextAnalizer x = new MyTextAnalizer();
		System.out.println(x.StringLength("Hello world"));
		System.out.println(x.charAt("Hello world", 2));

	}
}
