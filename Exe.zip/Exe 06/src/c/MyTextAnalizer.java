package c;

public class MyTextAnalizer implements TextAnalizer {

	private String text;

	@Override
	public int StringLength(String str) {
		int x = str.length();
		return x;
	}

	@Override
	public char charAt(String str, int index) {
		char c = str.charAt(index);
		return c;
	}

}
