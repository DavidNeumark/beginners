package c;

public interface TextAnalizer {

	int StringLength(String value);

	char charAt(String str, int index);

}
