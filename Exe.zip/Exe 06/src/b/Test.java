package b;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {

		BasicCalculator value = new Calculator();
		value.add(5);
		System.out.println(value.getResult());
		value.sub(3);
		System.out.println(value.getResult());
		value.mul(4);
		System.out.println(value.getResult());
		value.div(2);
		System.out.println(value.getResult());
		value.reset();
		System.out.println(value.getResult());

		Scanner sc = new Scanner(System.in);

		System.out.print("enter first number: ");
		double a = sc.nextInt();
		value.add(a);

		System.out.print("enter second number: ");
		double b = sc.nextInt();
	}

}
