package b;

public class Calculator implements BasicCalculator {

	private double res; // current result

	@Override
	public void add(double val) {
		res += val;
	}

	@Override
	public void sub(double val) {
		res -= val;

	}

	@Override
	public void mul(double val) {
		res *= val;

	}

	@Override
	public void div(double val) {
		res /= val;

	}

	@Override
	public void reset() {
		res = 0;
	}

	@Override
	public double getResult() {
		return res;
	}

}
