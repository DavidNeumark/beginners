package b;

public interface BasicCalculator {
	public class Calculator {

	}

	/**
	 * this method add a value x
	 */
	void add(double x);

	/**
	 * this method sum the value x
	 */
	void sub(double x);

	/**
	 * this method multiply the value x
	 */
	void mul(double x);

	/**
	 * this method divides the value x
	 */
	void div(double x);

	/**
	 * this method resets the value x
	 */
	void reset();

	/**
	 * this method return the result
	 */
	double getResult();
}
