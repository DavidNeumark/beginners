package d.Collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Type4 {
	public static void main(String[] args) {
		List<Integer> abc = new ArrayList<>();
		abc.add(222);
		abc.add(111);
		abc.add(333);
		abc.add(444);

		System.out.println(abc);

		Set<String> dfg = new TreeSet<>();
		dfg.add("BBB");
		dfg.add("AAA");
		dfg.add("CCC");
		dfg.add("DDD");

		System.out.println(dfg);

		Map<String, Integer> hij = new TreeMap<>();
		hij.put("MMM", 999);
		hij.put("NNN", 888);
		hij.put("PPP", 666);
		hij.put("OOO", 777);

		System.out.println(hij);
	}
}
