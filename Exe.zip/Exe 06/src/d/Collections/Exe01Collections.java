package d.Collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

public class Exe01Collections {

	public static void main(String[] args) {
		Collection<String> c;

		c = new ArrayList<String>();
		c.add("AAA");
		c.add("CCC");
		c.add("BBB");
		System.out.println(c);

		c = new LinkedList<>(c);
		c.add("DDD");
		c.add("AAA");
		System.out.println(c);

		c = new LinkedHashSet<>(c);
		c.add("ZZZ");
		System.out.println(c);

		c = new ArrayList<>(new HashSet<>(c));
		System.out.println(c);

		List<Integer> d = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			d.add((int) (Math.random() * 11));

		}
		System.out.println(d);

		d = new ArrayList<>(new HashSet<>(d));
		System.out.println(d);
	}

}
