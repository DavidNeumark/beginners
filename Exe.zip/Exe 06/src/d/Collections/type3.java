package d.Collections;

import java.util.HashSet;
import java.util.Set;

public class type3 {
	public static void main(String[] args) {

		Set<Integer> set = new HashSet<>();

		for (int i = 0; i < 10; i++) {
			set.add((int) (Math.random() * 101));
		}
		System.out.println(set);
		System.out.println(set.size());

	}
}
