package d.Collections;

import java.util.HashMap;
import java.util.Map;

public class Type2 {
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		map.put("Sunday", 1);
		map.put("Monday", 2);
		System.out.println(map);
		System.out.println(map.get("Sunday"));
	}
}
