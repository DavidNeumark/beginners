package d.Collections;

import java.util.ArrayList;
import java.util.List;

public class Type1 {
	public static void main(String[] args) {

		// ArrayList list = new ArrayList();
		// list.add(786);
		// list.add("AAA");
		// list.add(8);
		// System.out.println(list);

		List<String> list = new ArrayList<>();
		// list.add(786);
		list.add("AAA");
		list.add("BBB");
		// list.add(8);
		System.out.println(list);
		System.out.println(list.size());

		List<Integer> x = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			x.add((int) (Math.random() * 101));
		}
		System.out.println(x);
		System.out.println(x.size());
	}
}
