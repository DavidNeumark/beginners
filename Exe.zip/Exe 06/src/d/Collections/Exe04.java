package d.Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exe04 {

	public static void main(String[] args) {
		List<String> names = new ArrayList<>();
		names.add("Larry");
		names.add("David");
		names.add("James");
		names.add("Harrison");
		names.add("Dennis");

		System.out.println(names);

		Collections.sort(names);
		System.out.println(names);

	}

}
