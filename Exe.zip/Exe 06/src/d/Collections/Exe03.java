package d.Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Exe03 {

	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<>();

		map.put(878, "mmm");
		map.put(456, "jjj");
		map.put(324, "uuu");
		map.put(567, "lll");
		map.put(789, "ddd");

		Iterator<Integer> it = map.keySet().iterator();

		while (it.hasNext()) {
			int id = it.next();
			System.out.println(id + ": " + map.get(id));
		}
	}
}
