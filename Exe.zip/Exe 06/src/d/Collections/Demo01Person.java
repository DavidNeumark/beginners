package d.Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Demo01Person {
	public static void main(String[] args) {

		List<Person> persons = new ArrayList<>();

		persons.add(new Person(7, "fff", 78));
		persons.add(new Person(2, "mmm", 17));
		persons.add(new Person(6, "eee", 1));
		persons.add(new Person(5, "ddd", 42));
		persons.add(new Person(8, "lll", 86));
		persons.add(new Person(3, "www", 25));

		System.out.println(persons);

		Collections.sort(persons);
		System.out.println(persons);

		Collections.sort(persons, new PersonAgeComparator());
		System.out.println(persons);

		Collections.sort(persons, new PersonNameComparator());
		System.out.println(persons);

	}

}
