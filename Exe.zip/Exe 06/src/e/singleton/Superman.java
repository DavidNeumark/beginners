package e.singleton;

public class Superman {

	private String name;
	private int speed;

	private static Superman instance = new Superman();

	private Superman() {
	}

	public static Superman getInstance() {
		return instance;
	}
}
