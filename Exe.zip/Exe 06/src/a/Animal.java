package a;

public abstract class Animal {

	public abstract void speak();
}
