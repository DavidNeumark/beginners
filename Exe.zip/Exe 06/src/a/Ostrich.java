package a;

public class Ostrich extends Bird implements Flier {
	public void speak() {
		System.out.println("speak like a ostrich");
	}

	@Override
	public void takeoff() {
		System.out.println("takeoff like a ostrich");

	}

	@Override
	public void fly() {
		System.out.println("fly like a ostrich");

	}

	@Override
	public void land() {
		System.out.println("land like a ostrich");

	}
}
