package a;

public class Butterfly extends Insect implements Flier {
	public void speak() {
		System.out.println("speak like a butterfly");
	}

	@Override
	public void takeoff() {
		System.out.println("takeoff like a butterfly");

	}

	@Override
	public void fly() {
		System.out.println("fly like a butterfly");

	}

	@Override
	public void land() {
		System.out.println("land like a butterfly");

	}
}
