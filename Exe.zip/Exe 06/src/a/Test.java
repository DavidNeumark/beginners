package a;

public class Test {

	public static void main(String[] args) {

		Animal[] animals = { new Bat(), new Bat(), new Ant(), new Ant(), new Butterfly(), new Butterfly(), new Duck(),
				new Duck(), new Dog(), new Ostrich() };

		for (int i = 0; i < animals.length; i++) {
			animals[i].speak();
			if (animals[i] instanceof Flier) {
				Flier f = (Flier) animals[i];
				f.takeoff();
				f.fly();
				f.land();
			} else if (animals[i] instanceof AdvancedFlyer) {
				AdvancedFlyer a = (AdvancedFlyer) animals[i];
				a.takeoff();
				a.fly();
				a.land();
				a.Dive();

			} else if (animals[i] instanceof Navigator) {
				Navigator n = (Navigator) animals[i];
				n.Navigate();
			}
			System.out.println("===============================");
		}

	}
}
