package a;

public class Dog extends Mamal implements Navigator {
	public void speak() {
		System.out.println("speak like a dog");
	}

	@Override
	public void Navigate() {
		System.out.println("navigate like a dog");
	}

}
