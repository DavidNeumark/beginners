package a;

public abstract class Bird extends Animal {

}
