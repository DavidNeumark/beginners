package a;

public abstract class Mamal extends Animal {

}
