package a;

public abstract class Insect extends Animal {

}
