package a;

public class Duck extends Bird implements AdvancedFlyer {
	public void speak() {
		System.out.println("speak like a duck");
	}

	@Override
	public void takeoff() {
		System.out.println("takeoff like a duck");

	}

	@Override
	public void fly() {
		System.out.println("fly like a duck");

	}

	@Override
	public void land() {
		System.out.println("land like a duck");

	}

	@Override
	public void Dive() {
		System.out.println("dive like a duck");
	}

	@Override
	public void Navigate() {
		System.out.println("navigate like a duck");
	}
}
