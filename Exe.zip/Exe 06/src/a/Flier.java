package a;

public interface Flier {

	void takeoff();

	void fly();

	void land();
}
