package a;

public interface AdvancedFlyer extends Flier, Navigator {
	void Dive();
}
