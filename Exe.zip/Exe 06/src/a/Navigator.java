package a;

public interface Navigator {

	void Navigate();
}
