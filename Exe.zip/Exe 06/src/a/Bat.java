package a;

public class Bat extends Mamal implements Flier, Navigator {
	public void speak() {
		System.out.println("speak like a bat");

	}

	@Override
	public void takeoff() {
		System.out.println("takeoff like a bat");

	}

	@Override
	public void fly() {
		System.out.println("fly like a bat");

	}

	@Override
	public void land() {
		System.out.println("land like a bat");

	}

	@Override
	public void Navigate() {
		System.out.println("navigate like a bat");
	}
}
