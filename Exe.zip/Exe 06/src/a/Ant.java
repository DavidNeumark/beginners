package a;

public class Ant extends Insect implements Flier {

	public void speak() {
		System.out.println("speak like a ant");
	}

	@Override
	public void takeoff() {
		System.out.println("takeoff like a ant");

	}

	@Override
	public void fly() {
		System.out.println("fly like a ant");

	}

	@Override
	public void land() {
		System.out.println("land like a ant");

	}

}
