package b.arrays;

public class Demo1 {

	public static void main(String[] args) {
		int[] arr = new int[5];
		System.out.println(arr);

	}

}
