package b.arrays;

import java.util.Arrays;

public class Demo2 {

	public static void main(String[] args) {

		String[] arr = new String[5];
		System.out.println(Arrays.toString(arr));

		arr[2] = "abc";

	}

}
