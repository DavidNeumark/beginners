package b.arrays;

import java.util.Arrays;

public class Demo3 {

	public static void main(String[] args) {

		String[] arr = { "aaa", "bbb", "ccc" };
		System.out.println(Arrays.toString(arr));

	}

}
