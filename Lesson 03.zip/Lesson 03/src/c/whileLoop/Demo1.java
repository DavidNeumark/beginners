package c.whileLoop;

public class Demo1 {

	public static void main(String[] args) {
		int c = 1;

		while (c <= 100) {
			System.out.print(c + ", ");
			c++;
		}
		System.out.println();
	}
}
