package c.whileLoop;

public class Demo3 {

	public static void main(String[] args) {
		int c = 10;

		while (c <= 20) {
			System.out.print(c + ", ");
			c += 2;
		}
		System.out.println();
	}
}
