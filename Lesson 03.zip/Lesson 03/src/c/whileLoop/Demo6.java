package c.whileLoop;

public class Demo6 {

	public static void main(String[] args) {
		char c = 'A';

		while (c <= 'Z') {
			System.out.print(c + ", ");
			c++;
		}
	}
}
