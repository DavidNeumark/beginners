package c.whileLoop;

public class Demo2 {

	public static void main(String[] args) {
		int c = 25;

		while (c >= 10) {
			System.out.print(c + ", ");
			c--;
		}
		System.out.println();
	}
}
