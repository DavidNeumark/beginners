package c.whileLoop;

public class Demo5 {

	public static void main(String[] args) {
		char c = '�';

		while (c <= '�') {
			System.out.print(c + ", ");
			c++;
		}
	}
}
