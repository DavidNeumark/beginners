package f.forLoop;

public class Demo4 {

	public static void main(String[] args) {

		for (int i = 1, j = 99; i <= 99; i++, j--) {
			System.out.println(i + " + " + j + " = " + (i + j));
		}

	}

}
