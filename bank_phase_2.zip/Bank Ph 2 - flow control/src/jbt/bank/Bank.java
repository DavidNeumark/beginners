package jbt.bank;

public class Bank {

	private Client[] clients;
	private Logger logger;
	private Object accountUpdater;

	public Bank() {
		clients = new Client[100];
		logger = new Logger(null);
	}

	/**
	 * Returns the total sum of the bank clients fortune.
	 * 
	 * @return total fortune of bank clients.
	 */
	public float getBalance() {
		float balance = 0;

		for (int i = 0; i < clients.length; i++) {
			if (clients[i] != null) {
				balance += clients[i].getFortune();
			}
		}

		return balance;
	}

	/**
	 * Adds the specified client to the bank. This operation is logged.
	 * 
	 * @param client
	 *            the client to be added.
	 */
	public void addClent(Client client) {

		for (int i = 0; i < clients.length; i++) {
			if (clients[i] == null) {
				clients[i] = client;
				// log operation
				Log log = new Log(0, client.getId(), "client added", client.getFortune());
				logger.log(log);
				//
				return;
			}
		}

		System.out.println("client not added, bank is full.");
	}

	/**
	 * Remove the specified client from the bank. This operation is logged.
	 */
	public void removeClient(int clientId) {
		for (int i = 0; i < clients.length; i++) {
			if (clients[i] != null && clients[i].getId() == clientId) {
				float clientFortune = clients[i].getFortune();
				clients[i] = null;
				// log operation
				Log log = new Log(0, clientId, "client removed", clientFortune);
				logger.log(log);
				//
				return;
			}
		}

		System.out.println("client not found.");

	}

	/**
	 * Returns a copy array of the bank clients array.
	 * 
	 * @return an array of the bank clients.
	 */
	public Client[] getClients() {
		Client[] arr = new Client[clients.length];
		System.arraycopy(clients, 0, arr, 0, clients.length);
		return arr;
	}

	/** Not supported yet. */
	public void viewLogs() {

	}

	/** Not supported yet. */
	public void startAccountUpdater() {
		System.out.println(accountUpdater);
	}

}
