package jbt.bank;

public class Client {

	private int id;
	private String name;
	private float balance;
	private Account[] accounts = new Account[5];
	private float commissionRate;
	private float interestRate;
	private Logger logger;

	public Client(int id, String name, float balance) {
		super();
		this.id = id;
		this.name = name;
		this.balance = balance;
		logger = new Logger(null);
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public float getBalance() {
		return balance;
	}

	public Account[] getAccounts() {
		return accounts;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	/**
	 * Add the specified account to this client's accounts array if it is not full.
	 * This operation is logged.
	 * 
	 * @param account
	 *            the account to be added.
	 */
	public void addAccount(Account account) {

		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] == null) {
				accounts[i] = account;

				// log the operation ============================
				// 1. get the details of this operation.
				long timestamp = 0;
				int clientId = this.id;
				String description = "account added";
				float amount = account.getBalance();
				// 2. create a Log object using the above details.
				Log log = new Log(timestamp, clientId, description, amount);
				// 3. use the logger attribute to log the operation.
				this.logger.log(log);
				// ==============================================

				return; // end this method
			}
		}

		// if the program reached this line the accounts array is full.
		System.out.println("The client " + this.name + " already has " + accounts.length + " accounts.");
	}

	/**
	 * Return the account of the specified index or null if does not exist.
	 * 
	 * @param index
	 *            the index of the account in the accounts array.
	 * @return the specified account or null if does not exist.
	 */
	public Account getAccount(int index) {
		if (index >= 0 && index < accounts.length) {
			return accounts[index];
		} else {
			return null;
		}
	}

	/**
	 * Remove the account of the specified account id from this client accounts
	 * array (by assigning null to the specified index of the array) and transfer
	 * the account balance to the client balance.This operation is logged.
	 * 
	 * @param accountId
	 *            the specified account id to be removed.
	 */
	public void removeAccount(int accountId) {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] != null && accounts[i].getId() == accountId) {
				float accountBalance = accounts[i].getBalance();
				accounts[i] = null;
				// log the operation
				Log log = new Log(0, this.id, "account removed", accountBalance);
				this.logger.log(log);
				//
				return;
			}
		}

		System.out.println("account with id " + accountId + " not found");
	}

	/**
	 * Deposit the specified amount to this client's balance. This method calculates
	 * the commission owed using the commissionRate field and then deduct the owed
	 * commission from the client's balance. This operation is logged.
	 * 
	 * @param amount
	 *            the amount to be deposited.
	 */
	public void deposit(float amount) {
		float commission = amount * commissionRate;
		this.balance += amount;
		this.balance -= commission;
		// log the operation
		Log log = new Log(0, this.id, "deposit to balance", amount);
		this.logger.log(log);
		log = new Log(0, this.id, "deposit commission", -commission);
		this.logger.log(log);
		//
	}

	/**
	 * Withdraw the specified amount from this client's balance. This method
	 * calculates the commission owed using the commissionRate field and then deduct
	 * the owed commission from the client's balance. This operation is logged.
	 * 
	 * @param amount
	 *            the amount to withdraw.
	 */
	public void withdraw(float amount) {
		float commission = amount * commissionRate;
		this.balance -= amount;
		this.balance -= commission;
		// log the operation
		Log log = new Log(0, this.id, "withdraw from balance", amount);
		this.logger.log(log);
		log = new Log(0, this.id, "withdraw commission", -commission);
		this.logger.log(log);
		//
	}

	/**
	 * Run over this client's accounts and add to each account the interest gained
	 * using the interestRate field. This operation is logged per each account
	 * updated.
	 */
	public void autoUpdateAccounts() {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] != null) {
				float accountBalance = accounts[i].getBalance();
				float interest = accountBalance * this.interestRate;
				accounts[i].setBalance(accountBalance + interest);
				// log operation
				Log log = new Log(0, this.id, "autoUpdateAccount " + accounts[i].getId(), interest);
				Logger logger = new Logger(null);
				logger.log(log);
				//
			}
		}
	}

	/**
	 * This method returns the fortune of this client calculated by the client's
	 * balance plus the total sum of the cilent's accounts.
	 * 
	 * @return the fortune of this client.
	 */
	public float getFortune() {
		float fortune = this.balance;

		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] != null) {
				fortune += accounts[i].getBalance();
			}
		}

		return fortune;
	}

}
