package jbt.bank;

/**
 * A logger is a mechanism for handling log instances. Generally a logger is
 * expected to store logs in a permanent storage such as a file or database.
 */
public class Logger {

	private String driverName;

	public Logger(String driverName) {
		super();
		this.driverName = driverName;
	}

	/**
	 * Log the specified log by printing it to console. This method is intended to
	 * be re implemented in the future to store logs in a permanent data storage
	 * such as a file or database.
	 * 
	 * @param log
	 *            the log object to be logged.
	 */
	public void log(Log log) {
		System.out.println(log.getData());
	}

	public Log[] getLogs() {
		return null;
	}

}
