package jbt.bank.test;

import jbt.bank.Account;
import jbt.bank.Bank;
import jbt.bank.Client;

public class TestPh2 {

	public static void main(String[] args) {

		Bank bank = new Bank();

		Client c1 = new Client(101, "Yosi", 5_000);
		Client c2 = new Client(102, "Dan", 25_000);
		Client c3 = new Client(103, "Ruth", 9_500);

		System.out.println("=== test adding clients to bank:");
		bank.addClent(c1);
		bank.addClent(c2);
		bank.addClent(c3);

		System.out.println("=== test client withdraw");
		System.out.println(c1.getName() + " balance: " + c1.getBalance());
		c1.withdraw(200);
		System.out.println(c1.getName() + " balance: " + c1.getBalance());

		System.out.println("=== test add account");
		Account ac = new Account(10001, 100);
		c1.addAccount(ac);

		System.out.println("=== test get client fortune");
		System.out.println(c1.getFortune());

		System.out.println("=== test get bank balance");
		System.out.println(bank.getBalance());

		System.out.println("=== test removing client from bank:");
		bank.removeClient(102);

		System.out.println("=== test get bank balance");
		System.out.println(bank.getBalance());
	}

}
