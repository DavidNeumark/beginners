package exercise_class;

public class Test1 {
	public static void main(String[] args) {
		Book b1 = new Book("Livro 1", "Thomas", 102);
		Book b2 = new Book("Livro 2", "James", 202);
		Book b3 = new Book("Livro 3", "Steven", 302);

		System.out.println(b1);
		b1.toString();

	}
}
