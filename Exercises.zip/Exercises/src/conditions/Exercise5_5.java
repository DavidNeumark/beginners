package conditions;

public class Exercise5_5 {
	public static void main(String[] args) {
		int a = (int) (Math.random() * 101);
		int b = (int) (Math.random() * 101);
		int c = (int) (Math.random() * 101);
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);

		if (a > b && a > c) {
			System.out.println(a);
		} else if (b > c) {
			System.out.println(b);

		} else {
			System.out.println(c);
		}
	}
}
