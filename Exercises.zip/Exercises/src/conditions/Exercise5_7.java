package conditions;

public class Exercise5_7 {
	public static void main(String[] args) {
		int year = (int) (Math.random() * 2101);
		System.out.println("year " + year);
		if (year % 4 == 0 && year % 100 != 0) {
			System.out.println("leap year");
		} else if (year % 100 == 0 && year % 400 == 0) {
			System.out.println("leap year");

		} else {
			System.out.println("not leap year");
		}
	}
}
