package conditions;

public class Teste {
	public static void main(String[] args) {
		int minimum = 4;
		int maximum = 100;
		int randomNum = (minimum - 1) + (int) (Math.random() * (maximum - minimum) + 1);
		System.out.println(randomNum);
	}
}
