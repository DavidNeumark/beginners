package conditions;

public class Exercise5_1 {
	public static void main(String[] args) {

		int a = (int) (Math.random() * 101);
		int b = (int) (Math.random() * 101);
		System.out.println(a);
		System.out.println(b);

		if (a > b) {
			System.out.println(a);
		} else
			System.out.println(b);
	}

}
