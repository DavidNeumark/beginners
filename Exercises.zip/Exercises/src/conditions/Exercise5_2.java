package conditions;

public class Exercise5_2 {
	public static void main(String[] args) {
		int a = (int) (Math.random() * 101);
		System.out.println("a = " + a);
		if (a > 50) {
			System.out.println("Big!");
		} else if (a < 50) {
			System.out.println("Small!");
		} else {
			System.out.println("Bingo!");
		}
	}
}