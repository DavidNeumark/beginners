package conditions;

public class Exercise5_6 {
	public static void main(String[] args) {
		double salary = (int) (Math.random() * 6_000);
		System.out.println("salary = " + salary);

		if (salary < 23_000) {
			salary = salary * 1.1;
		} else if (salary < 50_000) {
			salary = salary * 1.2;
		} else if (salary < 100_000) {
			salary = salary * 1.3;
		} else {
			salary = salary * 1.4;
		}
		System.out.println("salary + tax = " + salary);
	}
}
