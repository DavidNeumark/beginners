package conditions;

public class Exercise5_4 {
	public static void main(String[] args) {
		int a = 5000;
		int b = 6000;
		double salary = a + (int) (Math.random() * (b - a) + 1);
		System.out.println("old salary = " + salary);
		if (salary * 1.1 <= 6000) {
			salary = salary * 1.1;
			System.out.println("new salary = " + salary);
		} else {
			System.out.println("no changes");
		}
	}
}
