package loops;

public class Exercise6_7 {
	public static void main(String[] args) {
		int num = (int) (Math.random() * 101);
		int factor = 1;
		System.out.println("num = " + num);

		for (int i = 1; i <= num; i++) {
			factor = factor * i;
			System.out.print(factor + ", ");
		}
		System.out.println();
		System.out.println("fac = " + factor);
	}

}
