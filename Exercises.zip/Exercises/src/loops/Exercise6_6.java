package loops;

public class Exercise6_6 {

	public static void main(String[] args) {
		int num = (int) (Math.random() * 100_000);
		int numOriginal = num;
		// num = 45;

		int rev = 0;
		System.out.println("num = " + num);

		while (num != 0) {
			rev *= 10;
			rev += num % 10;
			num = num / 10;
		}
		if (rev == numOriginal) {
			System.out.println("this number a palindrome!!");

		} else {
			System.out.println("This is NOT a palindrome!");
		}
	}

}
