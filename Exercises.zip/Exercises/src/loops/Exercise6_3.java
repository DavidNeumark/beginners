package loops;

public class Exercise6_3 {
	public static void main(String[] args) {
		int r = (int) (Math.random() * 101);
		System.out.println("r = " + r);

		for (int i = 0; i <= r; i += 2) {
			System.out.print(i + ", ");
		}
	}
}
