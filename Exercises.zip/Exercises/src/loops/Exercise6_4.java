package loops;

public class Exercise6_4 {
	public static void main(String[] args) {

		int max = (int) (Math.random() * 101);
		int den = (int) (Math.random() * 101);
		System.out.println("max = " + max);
		System.out.println("den = " + den);

		if (den > max) {
			int n = max;
			max = den;
			den = n;
		} else {

		}
		for (int i = 0; i <= max; i++) {
			if (i % den == 0) {
				System.out.print(i + ", ");
			} else {
			}

		}
	}
}
