package loops;

public class Exercise6_2 {
	public static void main(String[] args) {

		int r = (int) (Math.random() * 101);
		int s = (int) (Math.random() * 101);
		System.out.println("r = " + r);
		System.out.println("s = " + s);

		if (r > s) {
			int t = r;
			r = s;
			s = t;
		} else {
		}
		for (int i = r; i <= s; i++) {
			System.out.print(i + ", ");

		}
	}
}