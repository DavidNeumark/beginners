package loops;

public class Exercise6_10_Boom {
	public static void main(String[] args) {

		int number = (int) (Math.random() * 101);
		int a = number;
		System.out.println(number);

		if (number % 7 == 0) {
			System.out.println("Boom!!!");

		}
		while (number > 0) {
			if (number % 10 == 7) {
				System.out.println("Boom!");
			}
			number = number / 10;
		}
		System.out.println(a);
	}
}
