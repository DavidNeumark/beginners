package loops;

public class Exercise6_1 {
	public static void main(String[] args) {
		int r = (int) (Math.random() * 101);
		System.out.println("r = " + r);
		for (int i = 1; i <= r; i++) {
			System.out.print(i + ", ");

		}
	}

}
