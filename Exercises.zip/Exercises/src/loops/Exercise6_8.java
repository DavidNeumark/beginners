package loops;

public class Exercise6_8 {
	public static void main(String[] args) {
		int number = (int) (Math.random() * 101);
		long fibo1 = 0, fibo2 = 1, fibonacci = 1;
		long i = 1;

		for (i = 1; i < number; i++) {
			fibonacci = fibo1 + fibo2;
			fibo1 = fibo2;
			fibo2 = fibonacci;
		}
		System.out.println("The fibonacci number of " + i + " is: " + fibonacci);

	}
}
