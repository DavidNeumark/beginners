package arrays;

import java.util.Arrays;

public class Exercise7_4 {
	public static void main(String[] args) {
		int[] arr1 = new int[10];
		int[] arr2 = new int[10];
		int i = 0;
		int j = 9;
		for (i = 0; i < arr1.length; i++) {
			arr1[i] = (int) (Math.random() * 101);
		}
		System.arraycopy(arr1, 0, arr2, 0, 10);
		System.out.println(Arrays.toString(arr1));

		for (i = 0, j = 9; i < arr2.length; i++, j--) {
			arr1[i] = arr2[j];

		}
		System.out.println(Arrays.toString(arr1));

	}
}
