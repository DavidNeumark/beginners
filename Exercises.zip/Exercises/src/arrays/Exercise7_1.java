package arrays;

import java.util.Arrays;

public class Exercise7_1 {

	public static void main(String[] args) {

		int[] arr = new int[10];
		int i = 0;
		int sum1 = 0;
		int sum2 = 0;
		int avg1 = 0;
		int avg2 = 0;

		for (i = 0; i < 10; i++) {
			arr[i] = (int) (Math.random() * 101);
		}
		sum1 = arr[0] + arr[1] + arr[2] + arr[3] + arr[4] + arr[5] + arr[6] + arr[7] + arr[8] + arr[9];
		System.out.println("sum = " + sum1);
		avg1 = sum1 / 10;
		System.out.println("avg = " + avg1);
		System.out.println(Arrays.toString(arr));

		for (i = 0; i < 10; i++) {
			sum2 = sum2 + arr[i];
		}
		avg2 = sum2 / 10;
		System.out.println("sum2 = " + sum2);
		System.out.println("avg2 = " + avg2);

	}

}
