package arrays;

public class Test1 {

	public static void main(String[] args) {
		int[] arraytwo = { 0, 1, 2, 3, 4, 4, 6, 7, 8, 9 };
		projecttwo(arraytwo);
	}

	public static void projecttwo(int[] array) {
		/*
		 * Program that takes 10 numbers as input and displays the mode of these
		 * numbers. Program should use parallel arrays and a method that takes
		 * array of numbers as parameter and returns max value in array
		 */
		int modetracker[] = new int[10];
		int max = 0;
		int number = 0;
		for (int i = 0; i < array.length; i++) {
			modetracker[array[i]] += 1; // Add one to each index of modetracker
										// where the element of array[i]
										// appears.
		}

		int index = 0;
		for (int i = 1; i < modetracker.length; i++) {
			int newnumber = modetracker[i];
			if ((newnumber > modetracker[i - 1]) == true) {
				index = i;
			}
		}
		System.out.println(+index);

	}
}
