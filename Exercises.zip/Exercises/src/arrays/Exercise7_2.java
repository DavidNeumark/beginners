package arrays;

import java.util.Arrays;

public class Exercise7_2 {
	public static void main(String[] args) {
		int[] a = new int[50];
		int b = 0;
		int id = 0;
		for (int i = 0; i < 50; i++) {
			a[i] = (int) (Math.random() * 101);
			if (a[i] > b) {
				b = a[i];
				id = i;

			} else {

			}
		}
		System.out.println(Arrays.toString(a));
		System.out.println("the highest number is: " + a[id] + ", and his index is: " + id);

	}
}
