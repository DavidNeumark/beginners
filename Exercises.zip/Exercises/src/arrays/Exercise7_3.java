package arrays;

import java.util.Arrays;

public class Exercise7_3 {
	public static void main(String[] args) {
		int[] arr1 = new int[10];
		int i = 0;
		int j = 0;
		int[] arr2 = new int[j];
		for (i = 0; i < arr1.length; i++) {
			arr1[i] = (int) (Math.random() * 11);

		}
		System.out.println(Arrays.toString(arr1));
		i = 0;
		j = 0;
		for (i = 0, j = 0; i < arr1.length; i++) {
			if (arr1[i] == arr1[j]) {

			}

		}
	}
}
