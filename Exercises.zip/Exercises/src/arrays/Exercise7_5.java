package arrays;

import java.util.Arrays;

public class Exercise7_5 {
	public static void main(String[] args) {
		int[][] student = new int[20][10];
		int avgGrade = 0;
		int avgClass = 0;
		for (int i = 0; i < student.length; i++) {
			for (int j = 0; j < student[i].length; j++) {
				student[i][j] = (int) (Math.random() * 101);
				System.out.print(student[i][j] + "\t");

				avgGrade = student[i][j] + avgGrade;

			}
			avgGrade = avgGrade / 10;
			System.out.println();
			System.out.println("The avg grade of student " + i + " is: " + avgGrade);
			avgClass = avgGrade + avgClass;
			avgGrade = 0;
			System.out.println();
		}

		avgClass = avgClass / 20;
		System.out.println("The average grade of the class is: " + avgClass);
		System.out.println(Arrays.deepToString(student));

	}
}
