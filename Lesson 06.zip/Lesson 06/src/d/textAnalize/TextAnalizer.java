package d.textAnalize;

public interface TextAnalizer {

	int stringLength(String str);

	char charAt(String str, int index);
}
