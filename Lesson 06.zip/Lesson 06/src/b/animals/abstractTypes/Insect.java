package b.animals.abstractTypes;

public abstract class Insect extends Animal {

}
