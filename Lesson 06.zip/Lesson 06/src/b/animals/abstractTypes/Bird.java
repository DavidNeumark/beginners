package b.animals.abstractTypes;

public abstract class Bird extends Animal {

}
