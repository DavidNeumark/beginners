package b.animals.abstractTypes;

public abstract class Animal {

	public abstract void speak();

}
