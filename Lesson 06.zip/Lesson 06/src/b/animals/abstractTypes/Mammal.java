package b.animals.abstractTypes;

public abstract class Mammal extends Animal {

}
