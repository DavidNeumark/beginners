package b.animals.interfaceTypes;

public interface Navigator {

	void navigate();

}
