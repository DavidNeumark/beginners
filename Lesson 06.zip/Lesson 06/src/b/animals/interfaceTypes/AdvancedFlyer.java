package b.animals.interfaceTypes;

public interface AdvancedFlyer extends Flyer, Navigator {

	void dive();
}
