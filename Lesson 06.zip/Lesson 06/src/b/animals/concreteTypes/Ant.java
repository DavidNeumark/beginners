package b.animals.concreteTypes;

import b.animals.abstractTypes.Insect;

public class Ant extends Insect {

	@Override
	public void speak() {
		System.out.println("speak like an ant");

	}

}
