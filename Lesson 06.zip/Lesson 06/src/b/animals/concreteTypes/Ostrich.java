package b.animals.concreteTypes;

import b.animals.abstractTypes.Bird;

public class Ostrich extends Bird {

	@Override
	public void speak() {
		System.out.println("speak like an ostrich");
	}
}
