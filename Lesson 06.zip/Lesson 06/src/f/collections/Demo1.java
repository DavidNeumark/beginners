package f.collections;

import java.util.ArrayList;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		List list = new ArrayList();
		list.add(5);
		list.add(2);
		list.add("AAA");
		list.add(99);
		System.out.println(list);
	}
}
