package f.collections;

import java.util.HashMap;
import java.util.Map;

public class Tar3 {

	public static void main(String[] args) {
		Map<String, Integer> days = new HashMap<>();
		days.put("Sunday", 1);
		days.put("Monday", 2);
		days.put("Tueday", 3);
		days.put("Wednesday", 4);
		days.put("Thursday", 5);
		days.put("Friday", 6);
		days.put("Saturday", 7);
	}
}
