package c.calc.impl;

import c.calc.BasicCalculator;

public class SimpleCalculator implements BasicCalculator {

	@Override
	public void add(double val) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sub(double val) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mul(double val) {
		// TODO Auto-generated method stub

	}

	@Override
	public void div(double val) {
		// TODO Auto-generated method stub

	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub

	}

	@Override
	public double getResult() {
		// TODO Auto-generated method stub
		return 0;
	}

}
