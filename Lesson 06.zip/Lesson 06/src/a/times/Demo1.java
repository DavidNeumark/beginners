package a.times;

import java.util.Date;

public class Demo1 {

	public static void main(String[] args) {

		long ts = System.currentTimeMillis();
		System.out.println(ts);

		Date date = new Date();
		System.out.println(date);
	}
}
