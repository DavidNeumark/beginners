package core.dao;

import java.util.Collection;

import core.beans.Company;
import core.beans.Coupon;
import core.exceptions.CouponSystemException;

public interface CompanyDAO {
	
	
	
	void createCompany(Company company) throws CouponSystemException;
	Company readCompany(Company company) throws CouponSystemException;
	Collection<Coupon> readCompanyCoupons(Company company) throws CouponSystemException;

}
