package core.dao.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import core.beans.Company;
import core.beans.Coupon;
import core.dao.CompanyDAO;
import core.database.ConnectionPool;
import core.exceptions.CouponSystemException;

public class CompanyDAODB implements CompanyDAO {

	@Override
	public void createCompany(Company company) throws CouponSystemException {
		Connection con = ConnectionPool.getInstance().getConnection();
		String sql = "insert into company values(?,?,?,?)";
		try(PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setLong(1, company.getId());
			pstmt.setString(2, company.getName());
			pstmt.setString(3, company.getPassword());
			pstmt.setString(4, company.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new CouponSystemException("createCompany failed", e);
		}finally {
			ConnectionPool.getInstance().returnConnection(con);
		}

	}

	@Override
	public Company readCompany(Company company) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Coupon> readCompanyCoupons(Company company) throws CouponSystemException {
		
		Collection<Coupon> coupons = new HashSet<>();
		
		String sql1 = "select couponId from companyCoupon where compId = ?";
		String sql2 = "select * from coupon where id = ?";
		
		
		Connection con = ConnectionPool.getInstance().getConnection();
		try(PreparedStatement pstmt1 = con.prepareStatement(sql1);
				PreparedStatement pstmt2 = con.prepareStatement(sql2);) {
			pstmt1.setLong(1, company.getId());
			ResultSet rs = pstmt1.executeQuery();
			Set<Long> couponIds = new HashSet<>();
			while(rs.next()) {
				couponIds.add(rs.getLong(1));
			}
			
			
			for (Long couponId : couponIds) {
				pstmt2.setLong(1, couponId);
				ResultSet rs2 = pstmt2.executeQuery();
				Coupon c = new Coupon();
				rs2.next();
				c.setId(rs2.getLong(1));
				c.setName(rs2.getString(2));
				coupons.add(c);
			}
		} catch (SQLException e) {
			throw new CouponSystemException("createCompany failed", e);
		}finally {
			ConnectionPool.getInstance().returnConnection(con);
		}
		return coupons;
	}


}
