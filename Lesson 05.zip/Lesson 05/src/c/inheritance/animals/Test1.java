package c.inheritance.animals;

public class Test1 {

	public static void main(String[] args) {
		// Animal a = new Animal();
		// a.speak();

		Dog dog = new Dog();
		dog.speak();

	}

}
