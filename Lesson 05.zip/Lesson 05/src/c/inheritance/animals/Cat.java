package c.inheritance.animals;

public class Cat extends Animal {
	@Override
	public void speak() {
		System.out.println("Miau");
	}
}
