package c.inheritance.animals;

public class Test4 {

	public static void main(String[] args) {

		Animal animal = new Cow();
		animal.speak();
		Dog dog = new Dog();
	}

}
