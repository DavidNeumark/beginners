package c.inheritance.animals;

public class Fish extends Animal {

	@Override
	public void speak() {
		System.out.println("speak like a fish");

	}

}
