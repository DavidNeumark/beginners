package c.inheritance.animals;

public abstract class Animal {

	public abstract void speak();

}
