package test;

import bank.core.Account;
import bank.core.Client;

public class Test2 {

	public static void main(String[] args) {

		Client client = new Client(2222, "Yosi", 40000);
		Account account1 = new Account(111, 1000);
		Account account2 = new Account(222, 2000);
		Account account3 = new Account(333, 3000);
		Account account4 = new Account(444, 4000);
		Account account5 = new Account(555, 5000);
		Account account6 = new Account(666, 6000);
		client.addAccount(account1);
		client.addAccount(account2);
		client.addAccount(account3);
		client.autoUpdatesAccount();
		client.getFortune();

		System.out.println(client.getBalance());
		client.depositWithdraw(-500);
		System.out.println(client.getBalance());

		client.addAccount(account4);
		client.addAccount(account5);
		client.addAccount(account6);
		client.removeAccount(account1.getId());
		client.addAccount(account6);
		System.out.println("==============");
	}

}
