package test;

import bank.core.Log;
import bank.core.Logger;

public class Test {
	public static void main(String[] args) {

		long timestamp = System.currentTimeMillis();
		int clientId = 101;
		String description = "log and logger test";
		float amount = 45.60F;

		Log log = new Log(timestamp, clientId, description, amount);

		Logger logger = new Logger(null);
		logger.log(log);
	}
}
