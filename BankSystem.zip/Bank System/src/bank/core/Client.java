package bank.core;

public class Client {

	private int id;
	private String name;
	private float balance;
	private Account[] accounts = new Account[5];
	private float commissionRate;
	private float interestRate;

	public Client(int id, String name, float balance) {
		super();
		this.id = id;
		this.name = name;
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public int getId() {
		return id;
	}

	public Account[] getAccounts() {
		return accounts;
	}

	public void addAccount(Account account) {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] == null) {
				accounts[i] = account;
				// log the operation
				long timestamp = System.currentTimeMillis();
				int clientId = this.id;
				String description = "addAccount";
				float amount = account.getBalance();

				Log log = new Log(timestamp, clientId, description, amount);

				Logger logger = new Logger(null);
				logger.log(log);
				//
				return;
			}
		}

		System.out.println("account not added");
	}

	public void removeAccount(int accountId) {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] != null && accounts[i].getId() == accountId) {
				this.balance += accounts[i].getBalance(); // transfer money

				// log the operation
				long timestamp = System.currentTimeMillis();
				int clientId = this.id;
				String description = "removeAccount";
				float amount = accounts[i].getBalance();

				Log log = new Log(timestamp, clientId, description, amount);

				Logger logger = new Logger(null);
				logger.log(log);
				accounts[i] = null; // remove the account
				//
				return;

			}
		}
	}

	public void depositWithdraw(float amount) {

		balance = balance + (amount * (1 - commissionRate));

	}

	public void autoUpdatesAccount() {

		for (int i = 0; i < accounts.length; i++) {
			float balance = (accounts[i].getBalance() * (1 + interestRate));

			// log the operation
			long timestamp = System.currentTimeMillis();
			int clientId = this.id;
			String description = "transactionAccount";
			float amount = accounts[i].getBalance();

			Log log = new Log(timestamp, clientId, description, amount);

			Logger logger = new Logger(null);
			logger.log(log);
			//
			return;
		}

	}

	public float getFortune() {
		return balance;
	}
}
