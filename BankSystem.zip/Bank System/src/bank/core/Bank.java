package bank.core;

public class Bank {

}
