package types;

public class Citrus extends Fruit {

}
