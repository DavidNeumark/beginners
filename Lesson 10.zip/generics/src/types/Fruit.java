package types;

public class Fruit {

}
