package types;

public class Orange extends Citrus {

}
