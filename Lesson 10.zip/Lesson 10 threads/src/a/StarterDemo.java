package a;

public class StarterDemo {

	public static void main(String[] args) {
		Starter st1 = new Starter("st1");
		Starter st2 = new Starter("st2");
		st1.start();
		st2.start();

	}

}
