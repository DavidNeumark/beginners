package b.staticImport;

import static java.lang.Math.PI;
import static java.lang.Math.random;

public class Demo1 {

	public static void main(String[] args) {

		System.out.println(PI);
		System.out.println(random());
	}

}
