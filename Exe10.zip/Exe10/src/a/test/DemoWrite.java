package a.test;

public class DemoWrite {
	public static void main(String[] args) {
		System.out.write(72);
		System.out.flush();
	}
}
